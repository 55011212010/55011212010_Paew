//
//  ViewController.swift
//  W4_OneTwoThree
//
//  Created by iStudents on 2/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var LabelOne: UILabel!
    @IBOutlet weak var LabelTwo: UILabel!
    @IBOutlet weak var LabelThree: UILabel!
    
    var sum1 = 0
    var sum2 = 0
    var sum3 = 0
    
    @IBAction func ActionOne(sender: AnyObject) {
        sum1 = sum1 + 1
        LabelOne.text = String(sum1)
    }
    @IBAction func ActionTwo(sender: AnyObject) {
        sum2 = sum2 + 2
        LabelTwo.text = String(sum2)
    }
    @IBAction func ActionThree(sender: AnyObject) {
        sum3 = sum3 + 3
        LabelThree.text = String(sum3)
    }
    @IBAction func ResetAll(sender: AnyObject) {
        LabelOne.text = "0"
        LabelTwo.text = "0"
        LabelThree.text = "0"
        
        sum1 = 0
        sum2 = 0
        sum3 = 0
    }


}

