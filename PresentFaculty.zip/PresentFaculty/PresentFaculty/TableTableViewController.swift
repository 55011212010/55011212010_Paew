
import UIKit

class TableViewController: UITableViewController {
    
    var listData = Array<Faculty>()
    override func viewDidLoad() {
        super.viewDidLoad()
        listData = data().getData()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return listData.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as TableViewCell
        
        cell.customImageView.image = listData[indexPath.row].facultyImage
        cell.customLabel.text = listData[indexPath.row].facultyName
        
        
        
        return cell
    }
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if(listData[indexPath.row].facultyName=="สาขาคอมพิวเตอร์แอนิเมชั่นและเกม"){
            let message = "ปรัชญา มุ่งผลิตและพัฒนาบุคลากรที่มีศักยภาพ ในการพัฒนาสื่อเทคโนโลยีสารสนเทศที่นำสมัย ด้วยความคิดเชิงสร้างสรรค์ และจัดการบนพื้นฐานความรู้ด้านเทคโนโลยีการสื่อสารยุคใหม่"
            let alert = UIAlertController(title: "สาขาคอมพิวเตอร์แอนิเมชั่นและเกม", message: message, preferredStyle: .Alert)
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(okButton)
            self.presentViewController(alert, animated: true, completion: nil)
        }
        if(listData[indexPath.row].facultyName=="สาขาวิทยาการคอมพิวเตอร์"){
            let message = "ปรัชญา มุ่งผลิตบัณฑิตให้มีความรู้ความสามารถด้านวิทยาการคอมพิวเตอร์ ทั้งภาคทฤษฎีและปฏิบัติ มีความคิดริเริ่มสร้างสรรค์และคิดวิเคราะห์อย่างเป็นระบบ มีความสามารถทางวิชาการ สนใจใฝ่หาความรู้ มีคุณธรรม และนำไปประยุกต์ใช้ในสังคมปัจจุบันได้"
            let alert = UIAlertController(title: "สาขาวิทยาการคอมพิวเตอร์", message: message, preferredStyle: .Alert)
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(okButton)
            self.presentViewController(alert, animated: true, completion: nil)
        }
        if(listData[indexPath.row].facultyName=="สาขาภูมิสารสนเทศ"){
            let message = "ปรัชญา เสริมสร้างองค์ความรู้คู่คุณธรรม เพื่อประยุกต์ใช้ศาสตร์ภูมิสารสนเทศ  ให้เกิดประโยชน์ต่อสังคมและท้องถิ่นอย่างยั่งยืน"
            let alert = UIAlertController(title: "สาขาภูมิสารสนเทศ", message: message, preferredStyle: .Alert)
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(okButton)
            self.presentViewController(alert, animated: true, completion: nil)
        }
        if(listData[indexPath.row].facultyName=="สาขาเทคโนโลยีสารสนเทศ"){
            let message = "ปรัชญา สาขาวิชาเทคโนโลยีสารสนเทศ คณะวิทยาการสารสนเทศ มหาวิทยาลัยมหาสารคาม มีความมุ่งมั่นในการผลิตบัณฑิตที่มีความรู้ ความสามารถด้านเทคโนโลยีสารสนเทศ สามารถประยุกต์งานด้านซอฟต์แวร์และการบริหารเทคโนโลยีสารสนเทศ ให้เป็นผู้ใฝ่รู้ สามารถพัฒนาตนเองให้เป็นคนดี มีคุณธรรม จริยธรรมในวิชาชีพเทคโนโลยีสารสนเทศ และมีความรู้ความสามารถทัดเทียมในระดับสากล รวมทั้งมุ่งสร้างสรรค์งานวิจัยและบริการวิชาการสู่สังคม"
            let alert = UIAlertController(title: "สาขาเทคโนโลยีสารสนเทศ", message: message, preferredStyle: .Alert)
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(okButton)
            self.presentViewController(alert, animated: true, completion: nil)
        }
        if(listData[indexPath.row].facultyName=="สาขาสารสนเทศศาสตร์"){
            let message = "ปรัชญา หลักสูตรนี้มุ่งผลิตบัณฑิตให้เป็นผู้มีความรู้ความสามารถ รวมทั้งมีคุณธรรมและจริยธรรมในการจัดการสารสนเทศและแหล่งการเรียนรู้ โดยการประยุกต์ใช้เทคโนโลยีสารสนเทศและการสื่อสารได้อย่างมีประสิทธิภาพ"
            let alert = UIAlertController(title: "สาขาสารสนเทศศาสตร์", message: message, preferredStyle: .Alert)
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(okButton)
            self.presentViewController(alert, animated: true, completion: nil)
        }
        if(listData[indexPath.row].facultyName=="สาขานิเทศศาสตร์"){
            let message = "ปรัชญา นำองค์ความรู้ บูรณาการกับภูมิปัญญาท้องถิ่นอย่างสร้างสรรค์ ด้วยจรรยาบรรณแห่งวิชาชีพนิเทศศาสตร์"
            let alert = UIAlertController(title: "สาขานิเทศศาสตร์", message: message, preferredStyle: .Alert)
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(okButton)
            self.presentViewController(alert, animated: true, completion: nil)
        }

    }
    
}
    
    

