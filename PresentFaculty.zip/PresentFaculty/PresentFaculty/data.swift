//
//  data.swift
//  PresentFaculty
//
//  Created by iStudents on 3/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class data: NSObject {
    func getData() -> Array<Faculty> {
        var tempArray = Array<Faculty>()
        let b1 = Faculty(bImage: UIImage(named: "cag.jpg"), bName: "สาขาคอมพิวเตอร์แอนิเมชั่นและเกม")
        tempArray.append(b1)
        
        let b2 = Faculty(bImage: UIImage(named: "cs.jpg"), bName: "สาขาวิทยาการคอมพิวเตอร์")
        tempArray.append(b2)
        
        let b3 = Faculty(bImage: UIImage(named: "gis.jpg"), bName: "สาขาภูมิสารสนเทศ")
        tempArray.append(b3)
        
        let b4 = Faculty(bImage: UIImage(named: "ict.jpg"), bName: "สาขาเทคโนโลยีสารสนเทศ")
        tempArray.append(b4)
        
        let b5 = Faculty(bImage: UIImage(named: "is.jpg"), bName: "สาขาสารสนเทศศาสตร์")
        tempArray.append(b5)
        
        let b6 = Faculty(bImage: UIImage(named: "mc.jpg"), bName: "สาขานิเทศศาสตร์")
        tempArray.append(b6)
        
        return tempArray
        
        
    }
    
}