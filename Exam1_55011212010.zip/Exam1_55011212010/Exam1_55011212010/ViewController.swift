//
//  ViewController.swift
//  Exam1_55011212010
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var subjectName: UITextField!
    @IBOutlet var midterm: UITextField!
    @IBOutlet var summidterm: UITextField!
    @IBOutlet var scoresave: UITextField!
    @IBOutlet var sumscoresave: UITextField!
    @IBOutlet var final: UITextField!
    @IBOutlet var sumfinal: UITextField!
    
    @IBOutlet var showoutput: UITableView!
    @IBOutlet var textviewShow: UITextView!
    
    @IBAction func Calculate(sender: AnyObject) {
        
        var name = String(subjectName.text as NSString)
        var mid = Int((midterm.text as NSString).intValue)
        var summid = Double((summidterm.text as NSString).doubleValue)
        var save = Int((scoresave.text as NSString).doubleValue)
        var sumsave = Double((sumscoresave.text as NSString).doubleValue)
        var fin = Int((final.text as NSString).intValue)
        var sumfin = Double((sumfinal.text as NSString).doubleValue)
        
        var Grade:String = " "
        
        var sumtotal = summid + sumsave + sumfin
        var total = mid + save + fin
        
        if total <= 100 {
            if sumtotal < 44 {
                Grade = "F"
            }
            else if sumtotal < 50 {
                Grade = "D"
            }
            else if sumtotal < 60 {
                Grade = "D+"
            }
            else if sumtotal < 62 {
                Grade = "C"
            }
            else if sumtotal < 68 {
                Grade = "C+"
            }
            else if sumtotal < 74 {
                Grade = "B"
            }
            else if sumtotal < 80 {
                Grade = "B+"
            }
            else {
                Grade = "A"
            }
            textviewShow.text = "\(name) ได้ \(sumtotal) คะแนน เกรด \(Grade)"
           
        }
        else{
            textviewShow.text = "คะแนนเต็มเกิน 100"
        }
    }
    @IBAction func cleardata(sender: AnyObject) {
        subjectName.text = nil
        midterm.text = nil
        summidterm.text = nil
        scoresave.text = nil
        sumscoresave.text = nil
        final.text = nil
        sumfinal.text = nil
        
        textviewShow.text = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

}

