

import Foundation
import UIKit

struct balloon {
    var balloonImage: UIImage
    var balloonName: String
    
    init (bImage: UIImage, bName: String) {
        self.balloonImage = bImage
        self.balloonName = bName
    }
}